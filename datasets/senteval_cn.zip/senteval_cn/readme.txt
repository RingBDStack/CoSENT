ATEC: https://github.com/IceFlameWorm/NLP_Datasets/tree/master/ATEC (重新划分了train、valid和test)
BQ: http://icrc.hitsz.edu.cn/info/1037/1162.htm
LCQMC: http://icrc.hitsz.edu.cn/Article/show/171.html
PAWSX: https://arxiv.org/abs/1908.11828 (只保留了中文部分)
STS-B: https://github.com/pluto-junzeng/CNSD
